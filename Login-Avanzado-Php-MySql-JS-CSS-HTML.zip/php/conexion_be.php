<?php

$conexion = mysqli_connect("localhost", "myexamen1td7", "bZ6ShJ5k", "examen1bd");

/*/
if ($conexion){
    echo "conectado";
}else{
        echo "no conectado";
}
*/

?>
